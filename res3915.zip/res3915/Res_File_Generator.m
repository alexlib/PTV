for i = 1:100
 file_name = ['added.',sprintf('1%04d',i)];
 fopen(file_name,'w+');
 file_name = ['ptv_is.',sprintf('1%04d',i)];
 fopen(file_name,'w+');
 file_name = ['rt_is.',sprintf('1%04d',i)];
 fopen(file_name,'w+');
end

fclose all;