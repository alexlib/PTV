for i = 1:100
 file_name = ['cam1.',sprintf('1%04d',i),'_targets'];
 fopen(file_name,'w+');
 file_name = ['cam2.',sprintf('1%04d',i),'_targets'];
 fopen(file_name,'w+');
 file_name = ['cam3.',sprintf('1%04d',i),'_targets'];
 fopen(file_name,'w+');
 file_name = ['cam4.',sprintf('1%04d',i),'_targets'];
 fopen(file_name,'w+');
end

fclose all;